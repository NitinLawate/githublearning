import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-account-closure',
  templateUrl: './admin-account-closure.component.html',
  styleUrls: ['./admin-account-closure.component.css']
})
export class AdminAccountClosureComponent {

}
