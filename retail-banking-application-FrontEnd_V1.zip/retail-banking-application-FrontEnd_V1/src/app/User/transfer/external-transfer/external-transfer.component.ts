import { Component } from '@angular/core';

@Component({
  selector: 'app-external-transfer',
  templateUrl: './external-transfer.component.html',
  styleUrls: ['./external-transfer.component.css']
})
export class ExternalTransferComponent {

}
