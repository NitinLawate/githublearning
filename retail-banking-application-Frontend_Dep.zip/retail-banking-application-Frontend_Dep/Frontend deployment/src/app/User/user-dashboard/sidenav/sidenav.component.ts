import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sidenav',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.css']
})
export class SidenavComponent  {
  // Flag to toggle the dropdown
  showDropdown = false;

  showAccountDropdown: boolean = false;
showProfileDropdown: boolean = false;


  constructor(private router: Router) {}

  
  toggleAccountDropdown() {
    this.showAccountDropdown = !this.showAccountDropdown;
  }
  
  toggleProfileDropdown() {
    this.showProfileDropdown = !this.showProfileDropdown;
  }
  

  // Redirect methods for each option
  redirectToComponent1() {
    this.router.navigate(['accountdetails']); 
  }

  redirectToComponent2() {
    this.router.navigate(['view-account-balance']); 
  }

  redirectToComponent3() {
    this.router.navigate(['account-closure']); 
  }

  redirectToComponent4() {
    this.router.navigate(['setup-profile']); 
  }
  redirectToComponent5() {
    this.router.navigate(['change-password']); 
  }
  redirectToComponent6() {
    this.router.navigate(['setup-budget']); 
  }
  redirectToComponent7() {
    this.router.navigate(['manage-notifications']); 
  }

}
