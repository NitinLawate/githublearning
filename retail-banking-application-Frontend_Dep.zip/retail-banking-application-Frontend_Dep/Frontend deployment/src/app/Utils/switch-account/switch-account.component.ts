import { Component, ElementRef, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-switch-account',
  templateUrl: './switch-account.component.html',
  styleUrls: ['./switch-account.component.css']
})
export class SwitchAccountComponent  {
  
  chooseAcc: string = '';
  chooseAccNo: string = '';
  dropdownOptionschooseAcc: any[] = [];
  dropdownOptionschooseAccNo: any[] = [];

  customerAccounts: any[] = [];
  customerDetails: any = {};

  onAccountTypeChange(): void {
    if (this.chooseAcc) {
      const filteredAccounts = this.customerAccounts.filter(
        (acc: { accounttype: string }) => acc.accounttype === this.chooseAcc
      );

      this.dropdownOptionschooseAccNo = filteredAccounts.map((acc: { accountnumber: any }) => ({
        value: acc.accountnumber,
        label: acc.accountnumber.toString(),
      }));

      if (this.dropdownOptionschooseAccNo.length > 0) {
        this.chooseAccNo = this.dropdownOptionschooseAccNo[0].value;
        this.getSelectedAccount(this.chooseAccNo);
        this.onAccountNumberChange();
      }
    }
  }
  
  getSelectedAccount(accountNumber: string): any {
    return this.customerAccounts.find((acc: { accountnumber: string }) => acc.accountnumber === accountNumber);
  }

  onAccountNumberChange(): void {
    if (this.chooseAccNo) {
      const selectedAccount = this.getSelectedAccount(this.chooseAccNo);
      this.updateAccountDetails(selectedAccount);
    }
  }

  updateAccountDetails(selectedAccount: any): void {
    if (selectedAccount) {

      this.customerDetails.accountHolder = `${this.customerDetails.firstName} ${this.customerDetails.lastName}`;
      this.customerDetails.branch = "Kharadi, Pune";
      this.customerDetails.ifscCode = "RBA000123";
      this.customerDetails.accountBalance = selectedAccount.totalbalance;
      this.customerDetails.unclearedFunds = 0;
      this.customerDetails.amountOnHold = 0;
      this.customerDetails.status = selectedAccount.accountstatus;
      this.customerDetails.primaryCard = selectedAccount.primaryCard;
      this.customerDetails.spendingLimit = selectedAccount.spendingLimit;
    }
  }

  onSelectAccountNo(event: any): void {
    const selectedIndex = (event.target as HTMLSelectElement).selectedIndex;
  
    if (this.dropdownOptionschooseAccNo.length > 0) {
      this.chooseAccNo = this.dropdownOptionschooseAccNo[selectedIndex].value;
      const selectedAccount = this.getSelectedAccount(this.chooseAccNo);
      this.updateAccountDetails(selectedAccount);
      this.onAccountNumberChange();
    }
  }
}
