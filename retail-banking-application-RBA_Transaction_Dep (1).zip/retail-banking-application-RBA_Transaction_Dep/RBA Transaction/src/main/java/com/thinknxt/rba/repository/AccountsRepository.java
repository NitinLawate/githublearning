//package com.thinknxt.rba.repository;
// 
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
//import org.springframework.stereotype.Repository;
//
//import com.thinknxt.rba.entities.Accounts;
// 
//@Repository
//@EnableJpaRepositories
//public interface AccountsRepository extends JpaRepository<Accounts, Long> {
//	boolean existsByAccountnumber(long accountnumber);
//	boolean existsByCustomerid(long customerid);
//}