//package com.thinknxt.rba.repository;
// 
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;
//
//import com.thinknxt.rba.entities.BenificiaryAccount;
// 
//@Repository
//public interface AddBenificiaryRepo extends JpaRepository<BenificiaryAccount, Integer> {
//	boolean existsByBenaccountnumberAndCustomerid(long benaccountnumber, int customerid);
//}