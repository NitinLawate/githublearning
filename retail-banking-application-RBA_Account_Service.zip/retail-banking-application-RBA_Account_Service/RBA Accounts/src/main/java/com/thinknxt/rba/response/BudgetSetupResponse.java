package com.thinknxt.rba.response;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BudgetSetupResponse {
	private int status;
	private String message;
	private Object data;
}