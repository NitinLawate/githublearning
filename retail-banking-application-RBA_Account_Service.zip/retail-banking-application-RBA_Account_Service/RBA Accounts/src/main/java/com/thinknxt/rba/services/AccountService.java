package com.thinknxt.rba.services;

import java.util.List;

import com.thinknxt.rba.dto.CustomerAccountDTO;
import com.thinknxt.rba.dto.TicketDTO;
import com.thinknxt.rba.entities.Accounts;
import com.thinknxt.rba.entities.Ticket;
import com.thinknxt.rba.response.CustomerAccountResponse;

public interface AccountService {

	public CustomerAccountResponse getCustomerAccounts(int customerid);

	public String fetchAccountStatusService(long account_number);

	public String updateAccountStatus(Long account_number, String accountStatus, String reason);

	public CustomerAccountDTO createAccount(int customerId, String accountType);

	public Accounts fetchAccountDetailsService(long account_number);

	public void updateAmount(Double newAmount, long accountNumber);

	public List<Accounts> getAccountsByCustomerId(int customerId);

	public boolean areAccountsMappedToCustomer(int customerId);

	public List<Accounts> getAllAccounts();

	public Ticket createTicket(TicketDTO ticketDTO);

	public boolean isTicketExists(TicketDTO ticketDTO);

	public List<Ticket> getAllTickets();

	public Ticket updateTicket(Long ticketId, TicketDTO ticketDTO);

	public Ticket getTicket(Long ticketId);

	public String closeAccount(Long accountNumber);

	public boolean isLastTicketRejected(TicketDTO ticketDTO);

	public List<Accounts> getAllBlockedAccounts();
	public List<Accounts> getBlockedAccountsByCustomerId(Integer customerId);

}
