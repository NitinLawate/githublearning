package com.thinknxt.rba.dto;

import lombok.Data;

import java.util.Date;

import com.thinknxt.rba.config.Generated;

@Data
@Generated
public class CustomerDTO {

    private int customerId;
    private String firstName;
    private String lastName;
    private Date dateOfBirth;
    private String gender;
    private String email;
    private String phoneNumber;
    private String panNumber;
    private String aadharNumber;
}
