package com.thinknxt.rba.entities;

import com.thinknxt.rba.config.Generated;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "ticket")
@Generated
public class Ticket {
	
    @Id
    @Column(name = "ticket_id")
//    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ticket_id_seq")
//    @SequenceGenerator(name = "ticket_id_seq", sequenceName = "ticket_id_seq", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long ticketId;
    
    @Column(name = "ticket_type")
    private String ticketType;
    
    @Column(name = "customer_id")
    private Long customerId;
    
    @Column(name = "account_number")
    private Long accountNumber;
    
    @Column(name = "account_type")
    private String accountType;
    
    @Column(name = "recipient_account_number")
    private Long recipientAccountNumber;
    
    @Column(name = "ticket_status")
    private String ticketStatus = "Active"; // Default value
    
    @Column(name = "transfer_fund")
    private String transferFund;
    
    @Column(name = "feedback")
    private String feedback;
  
}