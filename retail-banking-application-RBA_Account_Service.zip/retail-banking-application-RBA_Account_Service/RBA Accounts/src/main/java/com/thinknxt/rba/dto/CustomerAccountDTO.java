package com.thinknxt.rba.dto;

import com.thinknxt.rba.config.Generated;

import lombok.Data;

@Data
@Generated
public class CustomerAccountDTO {
	private String msg;
	private int status;
}
