package com.thinknxt.rba.response;

import com.thinknxt.rba.config.Generated;
import com.thinknxt.rba.entities.Customer;

import lombok.Data;

@Data
@Generated
public class CustomerResponse {

	private String message;
	private int status;
	private Customer Data;

    // Constructors, getters, and setters
}
	