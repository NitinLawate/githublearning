package com.thinknxt.rba.controllers;

import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.thinknxt.rba.dto.CustomerAccountDTO;
import com.thinknxt.rba.dto.TicketDTO;
import com.thinknxt.rba.entities.Accounts;
import com.thinknxt.rba.entities.Ticket;
import com.thinknxt.rba.response.AccountResponse;
import com.thinknxt.rba.response.AllAccountsResponse;
import com.thinknxt.rba.response.AllTicketsResponse;
import com.thinknxt.rba.response.AllblockResponse;
import com.thinknxt.rba.response.BlockStatusResponse;
import com.thinknxt.rba.response.CloseAccountResponse;
import com.thinknxt.rba.response.CustomerAccountResponse;
import com.thinknxt.rba.response.CustomerResponse;
import com.thinknxt.rba.response.TicketResponse;
import com.thinknxt.rba.services.AccountService;
import com.thinknxt.rba.utils.BlockStatus;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.persistence.EntityNotFoundException;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Positive;
import lombok.extern.slf4j.Slf4j;

@RestController
@Validated
@RequestMapping("/accounts")
@Slf4j
public class AccountsController {

	@Autowired
	private RestTemplate restTemplate;

	private final AccountService accountService;

	@Autowired
	public AccountsController(AccountService accountService) {
		this.accountService = accountService;
		this.restTemplate = restTemplate;
	}

	public void setRestTemplate(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}

	/**
	 * Retrieves accounts for a given customer ID.
	 *
	 * @param customerid The ID of the customer.
	 * @return ResponseEntity with CustomerAccountResponse containing accounts,
	 *         status, and message.
	 */
	@Operation(summary = "Get customer account")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Accounts retrieved successfully for customer ID: {}"),
			@ApiResponse(responseCode = "201", description = "No accounts found for the customer ID: {}") })
	@GetMapping("/customer/{customerid}")
	public ResponseEntity<CustomerAccountResponse> getCustomerAccounts(@PathVariable int customerid) {
		log.info("Received request to retrieve accounts for customer ID: {}", customerid);

		CustomerAccountResponse response = accountService.getCustomerAccounts(customerid);

		if (response.getStatus() == 200) {
			log.info("Accounts retrieved successfully for customer ID: {}", customerid);
			return new ResponseEntity<>(response, HttpStatus.OK);
		} else {
			log.info("No accounts found for the customer ID: {}", customerid);
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}

	}

	/**
	 * Updates account status for a given account number.
	 *
	 * @param accountnumber The account number of the customer.
	 * @param accountStatus The account Status that need to be updated.
	 * 
	 * @return ResponseEntity containing account status, status.
	 */
	@GetMapping("/updateAccountStatus/{accountnumber}/{accountStatus}/{reason}")
	public ResponseEntity<BlockStatusResponse> updateAccountStatus(@PathVariable Long accountnumber,
			@PathVariable String accountStatus, @PathVariable String reason) {
		log.info("Inside updateAccountStatus function of AccountsController class ");
		// BlockStatusResponse response= new BlockStatusResponse();
		String dbUpdatedStatus = null;
		String dbStatus = accountService.fetchAccountStatusService(accountnumber);
		if (dbStatus != null) {
			if (StringUtils.equals(dbStatus, accountStatus + BlockStatus.BLOCKED.toString())
					|| StringUtils.equals(dbStatus, BlockStatus.BLOCKED.toString())) {
				log.info("When DBStatus Matches Any of the blocked status..");
				return ResponseEntity.status(HttpStatus.OK)
						.body(new BlockStatusResponse(302, " Already blocked for " + accountnumber));
			} else if (StringUtils.equals(dbStatus, BlockStatus.ACTIVE.toString())) {
				log.info("When DBStatus is Active");
				if (StringUtils.equals(accountStatus, BlockStatus.BLOCKED.toString())) {
					dbUpdatedStatus = accountService.updateAccountStatus(accountnumber, BlockStatus.BLOCKED.toString(),
							reason);
				} else {
					dbUpdatedStatus = accountService.updateAccountStatus(accountnumber,
							accountStatus + BlockStatus.BLOCKED.toString(), reason);
				}
				return ResponseEntity.status(HttpStatus.OK).body(new BlockStatusResponse(200, dbUpdatedStatus));
			} else if (!StringUtils.equals(dbStatus, accountStatus + BlockStatus.CREDITBLOCKED.toString())
					|| !StringUtils.equals(dbStatus, accountStatus + BlockStatus.DEBITBLOCKED.toString())
					|| !StringUtils.equals(dbStatus, BlockStatus.BLOCKED.toString())) {
				log.info("When DBStatus is not in any of the Blocked Status");
				dbUpdatedStatus = accountService.updateAccountStatus(accountnumber, BlockStatus.BLOCKED.toString(),
						reason);
				return ResponseEntity.status(HttpStatus.OK).body(new BlockStatusResponse(200, dbUpdatedStatus));
				// return new ResponseEntity<>(dbUpdatedStatus, HttpStatus.OK);

			} else if (StringUtils.equals(accountStatus, BlockStatus.ACTIVE.toString())
					&& (dbStatus.contains(BlockStatus.BLOCKED.toString()))) {
				log.info("when account is blocked any type");

				dbUpdatedStatus = accountService.updateAccountStatus(accountnumber, BlockStatus.ACTIVE.toString(),
						reason);

				return ResponseEntity.status(HttpStatus.OK).body(new BlockStatusResponse(200, dbUpdatedStatus));
			} else {
				return ResponseEntity.status(HttpStatus.OK)
						.body(new BlockStatusResponse(400, accountnumber + " Doesn't exist"));
				// return new ResponseEntity<>(dbStatus + " status found for " + accountnumber,
				// HttpStatus.BAD_REQUEST);
			}
		} else {
			// return new ResponseEntity<>(dbStatus + " found for " + accountnumber,
			// HttpStatus.BAD_REQUEST);
			return ResponseEntity.status(HttpStatus.OK)
					.body(new BlockStatusResponse(400, accountnumber + " Doesn't exist"));
		}

	}

	@GetMapping("/unblockAccount/{accountNumber}/{accountStatus}/{reason}")
	public ResponseEntity<BlockStatusResponse> unblockAccount(@PathVariable Long accountNumber,
			@PathVariable String accountStatus, @PathVariable String reason) {
		String dbUpdatedStatus = null;
		String dbStatus = accountService.fetchAccountStatusService(accountNumber);
		if (dbStatus != null) {

			if (StringUtils.equals(dbStatus, BlockStatus.BLOCKED.toString())
					&& accountStatus.equals(BlockStatus.CREDITUNBLOCK.toString())) {
				log.info("when dbstatus is BLOCKED and uistatus is CREDITUNBLOCK. only DEBITBLOCKED");

				dbUpdatedStatus = accountService.updateAccountStatus(accountNumber, BlockStatus.DEBITBLOCKED.toString(),
						reason);
				return ResponseEntity.status(HttpStatus.OK).body(new BlockStatusResponse(200, dbUpdatedStatus));
			} else if (StringUtils.equals(dbStatus, BlockStatus.BLOCKED.toString())
					&& accountStatus.equals(BlockStatus.DEBITUNBLOCK.toString())) {
				log.info("when dbstatus is BLOCKED and uistatus is DEBITUNBLOCKED. only CREDITBLOCKED");

				dbUpdatedStatus = accountService.updateAccountStatus(accountNumber,
						BlockStatus.CREDITBLOCKED.toString(), reason);
				return ResponseEntity.status(HttpStatus.OK).body(new BlockStatusResponse(200, dbUpdatedStatus));
			} else if (StringUtils.equals(dbStatus, BlockStatus.BLOCKED.toString())
					&& accountStatus.equals(BlockStatus.ACTIVE.toString())) {
				log.info("when dbstatus is BLOCKED and uistatus is ACTIVE. Complete Unblock");

				dbUpdatedStatus = accountService.updateAccountStatus(accountNumber, BlockStatus.ACTIVE.toString(),
						reason);
				return ResponseEntity.status(HttpStatus.OK).body(new BlockStatusResponse(200, dbUpdatedStatus));
			} else if (dbStatus.contains(BlockStatus.BLOCKED.toString())
					&& StringUtils.equals(accountStatus, BlockStatus.CREDITUNBLOCK.toString())) {
				log.info("When dbstatus credit/debit blocked and uistatus CREDITUNBLOCK. only creditblocked");

				dbUpdatedStatus = accountService.updateAccountStatus(accountNumber, BlockStatus.ACTIVE.toString(),
						reason);
				return ResponseEntity.status(HttpStatus.OK).body(new BlockStatusResponse(200, dbUpdatedStatus));
			} else if (dbStatus.contains(BlockStatus.BLOCKED.toString())
					&& StringUtils.equals(accountStatus, BlockStatus.DEBITUNBLOCK.toString())) {
				log.info("When dbstatus credit/debit blocked and uistatus DEBITUNBLOCK. only creditblocked");

				dbUpdatedStatus = accountService.updateAccountStatus(accountNumber, BlockStatus.ACTIVE.toString(),
						reason);
				return ResponseEntity.status(HttpStatus.OK).body(new BlockStatusResponse(200, dbUpdatedStatus));
			} else {
				return ResponseEntity.status(HttpStatus.OK)
						.body(new BlockStatusResponse(302, "Account Number is already ACTIVE"));
			}
		} else {

			return ResponseEntity.status(HttpStatus.OK)
					.body(new BlockStatusResponse(400, accountNumber + " Doesn't exist"));
		}

	}

	/**
	 * Retrieves account status for a given account number.
	 *
	 * @param accountnumber The account number of the customer.
	 * @return ResponseEntity containing account status and status.
	 */
	@GetMapping("/fetchAccountStatus/{accountnumber}")
	public ResponseEntity<String> fetchAccountStatus(@PathVariable Long accountnumber) {
		log.info("Inside fetchAccountStatus function of AccountsController class ");
		if (accountnumber != null) {
			log.info("else part Inside fetchAccountStatus function of AccountsController class ");
			String accountStatus = accountService.fetchAccountStatusService(accountnumber);
			if (StringUtils.isBlank(accountStatus)) {
				return new ResponseEntity<>("Account Status Not Present for " + accountnumber, HttpStatus.BAD_REQUEST);
			} else {
				return new ResponseEntity<>(accountStatus, HttpStatus.OK);
			}

		} else {
			log.info("if part Inside fetchAccountStatus function of AccountsController class ");
			return new ResponseEntity<>("Account number cannot be null ", HttpStatus.BAD_REQUEST);
		}
	}

	@PostMapping("/create/{customerId}")
	public ResponseEntity<CustomerAccountDTO> createAccount(@PathVariable int customerId,
			@RequestParam String accountType) {
		CustomerAccountDTO customerAccountDTO = accountService.createAccount(customerId, accountType);

		return new ResponseEntity<>(customerAccountDTO, HttpStatus.OK);

	}

	@GetMapping("/fetchAccountDetails/{accountnumber}")
	public ResponseEntity<?> getAccountDetails(@PathVariable Long accountnumber) {
		log.info("Inside getAccountDetails function of AccountsController class ");
		if (accountnumber != null) {
			log.info("else part Inside getAccountDetails function of AccountsController class ");
			Accounts accountDetails = accountService.fetchAccountDetailsService(accountnumber);
			if (ObjectUtils.isEmpty(accountDetails)) {
				return new ResponseEntity<>("Account Details not present", HttpStatus.BAD_REQUEST);
			} else {
				
				return new ResponseEntity<>(accountDetails, HttpStatus.OK);
			}

		} else {
			log.info("if part Inside getAccountDetails function of AccountsController class ");
			return new ResponseEntity<>("Account number cannot be null ", HttpStatus.BAD_REQUEST);
		}
	}

	@PostMapping("/updateAmount")
	public ResponseEntity<Void> updateAmount(@RequestParam Double newAmount, @RequestParam long accountNumber) {
		accountService.updateAmount(newAmount, accountNumber);
		return ResponseEntity.ok().build();
	}

	/**
	 * Author : Vipul get customer details with account details which are mapped to
	 * it. New UI Implementation Retrieves account details for a given customer ID.
	 *
	 * @param customerId The ID of the customer.
	 * @return ResponseEntity with AccountResponse containing customer details,
	 *         accounts, status, and message.
	 */
	@Operation(summary = "Get account details for a customer")
	@ApiResponse(responseCode = "200", description = "Account details retrieved successfully", content = @Content(mediaType = "application/json", schema = @Schema(implementation = AccountResponse.class)))
	@ApiResponse(responseCode = "400", description = "Customer not found", content = @Content(mediaType = "application/json", schema = @Schema(implementation = AccountResponse.class)))
	@GetMapping("/details/{customerId}")
	public ResponseEntity<AccountResponse> getAccountDetails(
			@PathVariable @Positive(message = "Customer ID must be a positive integer") int customerId) {
		try {
			// Fetch customer details from the customer microservice
			String customerMicroserviceUrl = "http://localhost:1011/api/retailbanking/customer/fetchCustomer/{customerId}";
			ResponseEntity<CustomerResponse> customerResponseEntity = restTemplate.getForEntity(customerMicroserviceUrl,
					CustomerResponse.class, customerId);

			// Fetch accounts for the customer from the account microservice
			List<Accounts> accounts = accountService.getAccountsByCustomerId(customerId);

			if (customerResponseEntity != null) {
				if (customerResponseEntity.getBody().getData() != null) {
					AccountResponse response = new AccountResponse(HttpStatus.OK.value(), "Success",
							customerResponseEntity.getBody().getData(), accounts);
					return ResponseEntity.ok(response);
				} else {
					return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(
							new AccountResponse(HttpStatus.BAD_REQUEST.value(), "Customer Not Found", null, null));
				}

			} else {
				return ResponseEntity.status(HttpStatus.NOT_FOUND)
						.body(new AccountResponse(HttpStatus.NOT_FOUND.value(), "Customer Not Found", null, null));
			}

		} catch (HttpClientErrorException.NotFound ex) {
			return ResponseEntity.notFound().build();
		} catch (Exception ex) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(
					new AccountResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Internal server error", null, null));
		}
	}

	/**
	 * Get account details based on the provided customer ID.
	 *
	 * @param customerId The unique identifier for the customer.
	 * @return ResponseEntity with the result of the account details retrieval
	 *         operation.
	 */
	@GetMapping("/getaccount/{customerId}")
	public ResponseEntity<?> getAccountsByCustomerId(@PathVariable int customerId) {
		log.info("Inside getAccountsByCustomerId function of AccountsController class ");

		// Check if accounts are mapped based on customer ID
		boolean areAccountsMapped = accountService.areAccountsMappedToCustomer(customerId);

		if (areAccountsMapped) {
			return ResponseEntity.badRequest().body("Accounts found for the customer");
		} else {
			return ResponseEntity.ok("No accounts found for the customer");
		}
	}

	@GetMapping("/allAccounts")
	@Operation(summary = "Get All Accounts")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Accounts retrieved successfully"),
			@ApiResponse(responseCode = "404", description = "No accounts found") })
	public ResponseEntity<AllAccountsResponse> getAllAccounts() {
		try {
			List<Accounts> accounts = accountService.getAllAccounts();
			return ResponseEntity.ok(new AllAccountsResponse("Accounts retrieved successfully", 200, accounts));
		} catch (Exception e) {
			log.error("Error while fetching accounts", e);
			return ResponseEntity.status(404).body(new AllAccountsResponse("No accounts found", 404, null));
		}
	}

	/**
	 ** @author siddharth Creates a new ticket based on the provided TicketDTO.
	 *         Checks if a ticket already exists for the given customer and account
	 *         details. If a ticket exists, it checks if its status is "Rejected".
	 *         If the last ticket is rejected, a new ticket is created. If the last
	 *         ticket status is not "Rejected", the request is rejected. If no
	 *         ticket exists, a new ticket is created. Handles exceptions and
	 *         returns appropriate responses.
	 *
	 * @param ticketDTO The ticket data transfer object containing ticket details.
	 * @return ResponseEntity with TicketResponse containing response message,
	 *         status, and created ticket.
	 */
	@PostMapping("/ticket/create")
	public ResponseEntity<TicketResponse> createTicket(@Valid @RequestBody TicketDTO ticketDTO) {
		try {
			log.info("Inside createTicket controller method. TicketDTO: {}", ticketDTO);

			// Check if a ticket already exists for the given customer and account details
			if (accountService.isTicketExists(ticketDTO)) {

				log.debug("Ticket already exists. Checking if it's rejected.");

				// If ticket exists, check if its status is "Rejected"
				if (accountService.isLastTicketRejected(ticketDTO)) {
					log.debug("Last ticket is rejected. Creating a new ticket.");

					Ticket createdTicket = accountService.createTicket(ticketDTO);
					return ResponseEntity.status(HttpStatus.CREATED)
							.body(new TicketResponse("Ticket created successfully", 201, createdTicket));
				} else {
					log.debug("A ticket exists with status other than 'Rejected'. Cannot create a new ticket.");

					// If ticket status is not "Rejected", reject the request
					return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new TicketResponse(
							"A ticket already exists for the given customer and account details with status other than 'Rejected'. Cannot create a new ticket.",
							400, null));
				}
			} else {
				log.debug("No ticket exists. Creating a new ticket.");

				// If ticket does not exist, create a new ticket
				Ticket createdTicket = accountService.createTicket(ticketDTO);
				return ResponseEntity.status(HttpStatus.CREATED)
						.body(new TicketResponse("Ticket created successfully", 201, createdTicket));
			}
		} catch (Exception e) {
			log.error("Error processing createTicket request. Invalid input data", e);
			return ResponseEntity.badRequest().body(new TicketResponse("Invalid input data", 400, null));
		}
	}

	/**
	 * @author siddharth Retrieves all tickets. Handles exceptions and returns
	 *         appropriate responses.
	 *
	 * @return ResponseEntity with AllTicketsResponse containing response message,
	 *         status, and list of tickets.
	 */
	@GetMapping("/tickets")
	public ResponseEntity<AllTicketsResponse> getAllTickets() {
		try {
			log.info("Inside getAllTickets controller method");

			List<Ticket> tickets = accountService.getAllTickets();
			return ResponseEntity.ok(new AllTicketsResponse("Tickets retrieved successfully", 200, tickets));
		} catch (Exception e) {
			log.error("Failed to fetch tickets", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(new AllTicketsResponse("Failed to fetch tickets", 500, null));
		}
	}

	/**
	 * @author siddharth Updates a ticket with the provided ticket ID and TicketDTO.
	 *         Fetches the existing ticket by ID, updates its details, and saves the
	 *         updated ticket. Handles exceptions and returns appropriate responses.
	 *
	 * @param ticketId  The ID of the ticket to be updated.
	 * @param ticketDTO The ticket data transfer object containing updated ticket
	 *                  details.
	 * @return ResponseEntity with TicketResponse containing response message,
	 *         status, and updated ticket.
	 */
	@PutMapping("/ticket/update/{ticketId}")
	public ResponseEntity<TicketResponse> updateTicket(@PathVariable Long ticketId, @RequestBody TicketDTO ticketDTO) {
		try {
			log.info("Inside updateTicket controller method. TicketId: {}, TicketDTO: {}", ticketId, ticketDTO);

			Ticket updatedTicket = accountService.updateTicket(ticketId, ticketDTO);
			return ResponseEntity.ok(new TicketResponse("Ticket updated successfully", 200, updatedTicket));
		} catch (EntityNotFoundException ex) {
			log.error("Ticket not found with id: {}", ticketId, ex);

			return ResponseEntity.status(HttpStatus.NOT_FOUND)
					.body(new TicketResponse("Ticket not found with id: " + ticketId, 404, null));
		} catch (Exception e) {
			log.error("Error updating ticket with id: {}", ticketId, e);

			return ResponseEntity.badRequest().body(new TicketResponse("Invalid input data", 400, null));
		}
	}

	/**
	 * @author vruttantp Retrieves details of a specific ticket by its ID.
	 *
	 * @param ticketId The ID of the ticket to retrieve
	 * @return ResponseEntity containing the retrieved ticket details or an error
	 *         response
	 */
	@GetMapping("/getTicket/{ticketId}")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Ticket details retrieved successfully"),
			@ApiResponse(responseCode = "400", description = "Invalid input data"),
			@ApiResponse(responseCode = "404", description = "Ticket not found") })
	public ResponseEntity<TicketResponse> getTicket(@PathVariable Long ticketId) {
		try {
			Ticket ticket = accountService.getTicket(ticketId);
			return ResponseEntity.ok(new TicketResponse("Ticket details retrieved successfully", 200, ticket));
		} catch (EntityNotFoundException ex) {
			log.error("Ticket not found with id: " + ticketId);
			return ResponseEntity.status(HttpStatus.NOT_FOUND)
					.body(new TicketResponse("Ticket not found with id: " + ticketId, 404, null));
		} catch (Exception e) {
			return ResponseEntity.badRequest().body(new TicketResponse("Invalid input data", 400, null));
		}
	}

	/**
	 * @author vruttantp Retrieves all ticket IDs that are not CLOSED or REJECTED.
	 *
	 * @return ResponseEntity containing the retrieved ticket IDs or an error
	 *         response
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@GetMapping("/ticketIds")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Ticket IDs retrieved successfully"),
			@ApiResponse(responseCode = "500", description = "Failed to fetch tickets") })
	public ResponseEntity<AllTicketsResponse> getAllTicketIds() {
		try {
			log.info("Inside getAllTickets controller method");
			List<Ticket> tickets = accountService.getAllTickets();
			List<Long> ticketIds = tickets.stream()
					.filter(ticket -> !(ticket.getTicketStatus().equalsIgnoreCase("CLOSED")
							|| ticket.getTicketStatus().equalsIgnoreCase("REJECTED")))
					.map(Ticket::getTicketId).collect(Collectors.toList());

			return ResponseEntity.ok(new AllTicketsResponse("Ticket IDs retrieved successfully", 200, ticketIds));
		} catch (Exception e) {
			log.error("Failed to fetch tickets", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(new AllTicketsResponse("Failed to fetch tickets", 500, null));
		}
	}

	/**
	 * @author siddharth
	 * Endpoint for closing an account.
	 *
	 * This endpoint handles requests to close an account identified by its account
	 * number. It delegates the operation to the {@link AccountService} and returns
	 * an appropriate response based on the outcome.
	 *
	 * @param accountNumber The unique identifier of the account to be closed.
	 * @return ResponseEntity with a success message or an error message.
	 */
	@PostMapping("/close/{accountNumber}")
	public ResponseEntity<CloseAccountResponse> closeCustomerAccount(@PathVariable Long accountNumber) {
	    log.info("Received request to close account with account number: {}", accountNumber);
 
	    try {
	        String response = accountService.closeAccount(accountNumber);
	        if (response.equals("mailSent")) {
	            return ResponseEntity.ok(new CloseAccountResponse("Account closed successfully", "Email sent successfully", HttpStatus.OK.value()));
	        } else if (response.equals("mailFailed")) {
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new CloseAccountResponse("Failed to close account", "Failed to send email", HttpStatus.INTERNAL_SERVER_ERROR.value()));
	        } else if (response.equals("mailNotFound")) {
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new CloseAccountResponse("Failed to close account", "Unable to get the customer's email address", HttpStatus.INTERNAL_SERVER_ERROR.value()));
	        } else if (response.equals("nonZero")) {
	            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(new CloseAccountResponse("Account cannot be closed. Balance is non-zero.", "Failed to close account", HttpStatus.FORBIDDEN.value()));
	        } else {
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new CloseAccountResponse("Failed to close account", "Unknown error", HttpStatus.INTERNAL_SERVER_ERROR.value()));
	        }
	    } catch (Exception e) {
	        log.error("Error while closing account", e);
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new CloseAccountResponse("Failed to close account", "Unknown error", HttpStatus.INTERNAL_SERVER_ERROR.value()));
	    }
 
	}

	/**
	 * @author sonali
	 */
	@GetMapping("/getAllBlockedAccounts")
	public ResponseEntity<AllAccountsResponse> getAllBlockedAccounts() {
		try {
			List<Accounts> accounts = accountService.getAllBlockedAccounts();
			if (accounts != null) {
				return ResponseEntity.ok(new AllAccountsResponse("Accounts retrieved successfully", 200, accounts));
			} else {
				return ResponseEntity.ok(new AllAccountsResponse("No accounts found", 302, accounts));
			}
		} catch (Exception e) {
			log.error("Error while fetching accounts", e);
			return ResponseEntity.status(404).body(new AllAccountsResponse("No accounts found", 404, null));
		}

	}

	@GetMapping("/getBlockedAccountsByCustomerId/{customerId}")
	public ResponseEntity<AllblockResponse> getBlockedAccountsByCustomerId(@PathVariable Integer customerId) {
		try {
			List<Accounts> accounts = accountService.getBlockedAccountsByCustomerId(customerId);
			if (accounts != null && !accounts.isEmpty()) {
				return ResponseEntity.ok(new AllblockResponse(
						"Blocked Accounts retrieved successfully for " + customerId, 200, accounts, null));
			} else {
				return ResponseEntity
						.ok(new AllblockResponse("No Blocked accounts found for " + customerId, 302, accounts, null));
			}
		} catch (Exception e) {
			log.error("Error while fetching accounts", e);
			return ResponseEntity.status(404).body(new AllblockResponse("No accounts found", 404, null, null));
		}
	}

	@GetMapping("/getBlockedAccountsByAccountNumber/{accountNumber}")
	public ResponseEntity<AllblockResponse> getBlockedAccountsByAccountNumber(@PathVariable Long accountNumber) {
		try {
			Accounts accounts = accountService.fetchAccountDetailsService(accountNumber);
			if (accounts != null && accounts.getAccountstatus().contains(BlockStatus.BLOCKED.toString())) {
				return ResponseEntity
						.ok(new AllblockResponse("Retrieved Data for " + accountNumber, 200, null, accounts));
			} else if (accounts != null) {
				return ResponseEntity.ok(new AllblockResponse(accountNumber + " is not Blocked", 301, null, null));
			} else {
				return ResponseEntity.ok(new AllblockResponse(accountNumber + " is not Present.", 302, null, accounts));
			}
		} catch (Exception e) {
			log.error("Error while fetching accounts", e);
			return ResponseEntity.status(404).body(new AllblockResponse("No accounts found", 404, null, null));
		}
	}

}
