package com.thinknxt.rba.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.thinknxt.rba.entities.Accounts;
import com.thinknxt.rba.repository.AccountRepository;
import com.thinknxt.rba.response.BlockStatusResponse;
import com.thinknxt.rba.response.CustomerAccountResponse;

public class AccountServiceTest {

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Mock
	private AccountRepository accountRepository;

	@InjectMocks
	private AccountServiceImpl accountService;

	/**
	 * Test for successful retrieval of customer accounts.
	 */
	@Test
	public void testGetCustomerAccounts_Success() {
		// Mocking the repository response with a list of mock accounts
		List<Accounts> mockAccounts = Arrays.asList(
				new Accounts(123456789, 1, "Savings", "Active", "INR", "NO", LocalDateTime.now(), 1000.00, null),
				new Accounts(987654321, 1, "Checking", "Active", "INR", "YES", LocalDateTime.now(), 5000.00, null));
		when(accountRepository.findByCustomerid(1)).thenReturn(mockAccounts);

		// Calling the service method
		CustomerAccountResponse response = accountService.getCustomerAccounts(1);

		// Assertions
		assertEquals(200, response.getStatus());
		assertEquals("Accounts retrieved successfully", response.getMessage());
		assertEquals(mockAccounts, response.getData());
	}

	/**
	 * Test when no accounts are found for the customer.
	 */
	@Test
	public void testGetCustomerAccounts_NoAccountsFound() {
		// Mocking the repository response with an empty list
		when(accountRepository.findByCustomerid(2)).thenReturn(new ArrayList<>());

		// Calling the service method
		CustomerAccountResponse response = accountService.getCustomerAccounts(2);

		// Assertions
		assertEquals(201, response.getStatus());
		assertEquals("No accounts found for the customer", response.getMessage());
		assertEquals(null, response.getData());
	}
	
	   @Test
	    public void testFetchAccountStatusService_AccountExists() {
	        long accountNumber = 12345L;
	        Accounts mockAccount = new Accounts();
	        mockAccount.setAccountstatus("ACTIVE");
	        
	        when(accountRepository.findByAccountnumber(accountNumber)).thenReturn(mockAccount);

	        String result = accountService.fetchAccountStatusService(accountNumber);

	        assertEquals("ACTIVE", result);
	    }

	    @Test
	    public void testFetchAccountStatusService_AccountDoesNotExist() {
	        long accountNumber = 12345L;
	        when(accountRepository.findByAccountnumber(accountNumber)).thenReturn(null);

	        String result = accountService.fetchAccountStatusService(accountNumber);

	        assertNull(result);
	    }

	   

	    @Test
	    public void testUpdateAccountStatus_AccountDoesNotExist() {
	        long accountNumber = 12345L;
	        String newAccountStatus = "BLOCKED";
	        Accounts result=null;
	        when(accountRepository.findByAccountnumber(accountNumber)).thenReturn(result);


	        assertNull(result);
	    }
	    
	    /**
	     * Test case for successful retrieval of accounts for a customer ID.
	     */
	    @Test
	    void testGetAccountsByCustomerId_Success() {
	        // Mocking repository response
	        when(accountRepository.findByCustomerid(anyInt()))
	                .thenReturn(Collections.singletonList(new Accounts(/* provide necessary data */)));

	        // Perform the service call and assert the response
	        List<Accounts> accounts = accountService.getAccountsByCustomerId(123);

	        assertNotNull(accounts);
	        assertFalse(accounts.isEmpty());
	    }

	    /**
	     * Test case when no accounts are found for a given customer ID.
	     */
	    @Test
	    void testGetAccountsByCustomerId_CustomerNotFound() {
	        // Mocking repository response for customer not found
	        when(accountRepository.findByCustomerid(anyInt()))
	                .thenReturn(Collections.emptyList());

	        // Perform the service call and assert the response
	        List<Accounts> accounts = accountService.getAccountsByCustomerId(123);

	        assertNotNull(accounts);
	        assertTrue(accounts.isEmpty());
	    }
}
