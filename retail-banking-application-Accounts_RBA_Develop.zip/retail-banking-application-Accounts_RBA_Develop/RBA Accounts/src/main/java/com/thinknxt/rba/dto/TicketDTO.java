package com.thinknxt.rba.dto;

import com.thinknxt.rba.config.Generated;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
@Generated
public class TicketDTO {
	 @NotBlank(message = "Ticket type is required")
	    private String ticketType;

	    @NotNull(message = "Customer ID is required")
	    private Long customerId;

	    @NotNull(message = "Account number is required")
	    private Long accountNumber;

	    @NotBlank(message = "Account type is required")
	    private String accountType;

	    @NotNull(message = "Recipient account number is required")
	    private Long recipientAccountNumber;

	    @NotBlank(message = "Ticket status is required")
	    private String ticketStatus;

	    @NotBlank(message = "Transfer fund is required")
	    private String transferFund;

	    @Size(max = 50, message = "Feedback must be less than 50 characters")
	    private String feedback;
	}

