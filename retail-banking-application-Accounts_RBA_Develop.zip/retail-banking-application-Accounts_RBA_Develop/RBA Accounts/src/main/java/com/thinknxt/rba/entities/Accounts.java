package com.thinknxt.rba.entities;

import java.sql.Date;
import java.time.LocalDateTime;

import com.thinknxt.rba.config.Generated;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Generated
@Table(name = "accounts")
public class Accounts {

	@Id
	@Column(name = "account_number")
	private long accountnumber;
	
	@Column(name = "customer_id")
	private int customerid;
	
	@Column(name = "account_type")
	private String accounttype;
	
	@Column(name = "account_status")
	private String accountstatus;
	
	@Column(name = "currency")
	private String currency;
	
	@Column(name = "overdraft")
	private String overdraft;
	
	@Column(name = "creation_date")
	private LocalDateTime creationdate;
	
	@Column(name = "total_balance")
	private double totalbalance;	
	
	@Column(name = "block_reason")
	private String blockreason;
}
