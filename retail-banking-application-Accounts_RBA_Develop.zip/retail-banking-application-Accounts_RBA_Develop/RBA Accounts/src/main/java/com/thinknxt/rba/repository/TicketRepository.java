package com.thinknxt.rba.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.thinknxt.rba.entities.Ticket;

@Repository
public interface TicketRepository extends JpaRepository<Ticket, Long> {

	boolean existsByCustomerIdAndAccountNumberAndAccountType(Long customerId, Long accountNumber, String accountType);

	boolean existsByCustomerIdAndAccountNumberAndAccountTypeAndTicketStatus(Long customerId, Long accountNumber,
			String accountType, String ticketStatus);
	boolean
	existsByCustomerIdAndAccountNumberAndTicketType(Long customerId, Long accountNumber, String ticketType);

	Ticket findByTicketId(Long ticketId);
	@Query("SELECT t FROM Ticket t WHERE t.customerId = ?1 AND t.accountNumber = ?2 AND t.ticketType = ?3 ORDER BY t.ticketId DESC")
	 List<Ticket> findLastByCustomerIdAndAccountNumberAndTicketType(Long customerId, Long accountNumber, String ticketType);
}