package com.thinknxt.rba.response;

import java.util.List;

import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.thinknxt.rba.config.Generated;
import com.thinknxt.rba.entities.Accounts;
import com.thinknxt.rba.entities.Customer;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@Generated
public class BlockStatusResponse {
	private int statusCode;
    private String statusMessage;
}
