package com.thinknxt.rba.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.thinknxt.rba.config.Generated;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@Generated
public class CloseAccountResponse {
    private String accountStatus;
    private String emailStatus;
    private int statusCode;
}