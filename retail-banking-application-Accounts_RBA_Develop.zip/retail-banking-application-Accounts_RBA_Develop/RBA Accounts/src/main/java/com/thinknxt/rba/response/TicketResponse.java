package com.thinknxt.rba.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.thinknxt.rba.config.Generated;
import com.thinknxt.rba.entities.Accounts;
import com.thinknxt.rba.entities.Ticket;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Generated
@JsonInclude(Include.NON_NULL)
public class TicketResponse {

	private String message;
	private int status;
	private Ticket Data;

}