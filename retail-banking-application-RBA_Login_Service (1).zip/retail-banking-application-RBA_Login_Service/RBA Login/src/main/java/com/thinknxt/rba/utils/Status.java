package com.thinknxt.rba.utils;

import com.thinknxt.rba.config.Generated;

@Generated
public enum Status {
 
	DELETED,
	ACTIVE,
	INACTIVE,
	BLOCKED,
	LOCKED
}