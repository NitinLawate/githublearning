package com.thinknxt.rba.utils;

import com.thinknxt.rba.config.Generated;

@Generated
public enum DayTransaction {
    today,
    yesterday
}
